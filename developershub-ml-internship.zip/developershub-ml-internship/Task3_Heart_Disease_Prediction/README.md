# Heart Disease Prediction Pipeline

This project uses logistic regression to predict the presence of heart disease.

## Workflow

1. **Load Data**
   - Reads `heart.csv`.
2. **Preprocess Data**
   - Encodes categorical variables using `pd.get_dummies()`.
   - Splits into features (X) and target (y).
3. **Train-Test Split**
   - 80% training, 20% testing.
4. **Scaling**
   - Standardizes numeric features.
5. **Model Training**
   - Trains a logistic regression classifier.
6. **Evaluation**
   - Prints accuracy, confusion matrix, ROC AUC.
   - Plots ROC curve and feature importance.
   - Shows a feature correlation heatmap.

## Running the Script

Install dependencies:

