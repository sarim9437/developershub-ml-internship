# 📈 Stock Price Prediction — Task 2

This project demonstrates how to predict **next-day closing stock prices** using regression models in Python. The notebook guides you step by step through data loading, preparation, modeling, and evaluation.

---

## ✨ Project Overview

**Objective:**  
Predict the next day’s closing price of a selected stock based on historical data.

**Dataset:**  
Historical stock market data fetched from Yahoo Finance using the `yfinance` library.

**Workflow:**
- Select a stock (e.g., Apple, Tesla)
- Load and explore historical data
- Prepare features: Open, High, Low, Volume
- Train regression models to predict the Close price
- Evaluate and visualize predictions

---

## 🛠️ Technologies and Libraries

- Python 3.x
- [yfinance](https://pypi.org/project/yfinance/) — for downloading stock data
- pandas — data manipulation
- numpy — numerical operations
- scikit-learn — machine learning models and metrics
- matplotlib, seaborn — data visualization
- Jupyter Notebook — interactive development

---



