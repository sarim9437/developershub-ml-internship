# 🤖 DevelopersHub AI/ML Internship Tasks – June 2025

Welcome to my repository for the **AI/ML Engineering Internship** at **DevelopersHub Corporation**.  
This repo contains completed tasks that demonstrate essential skills in data analysis, machine learning modeling, evaluation, and visualization. 
🎯 **Completed Tasks:** Task 1, Task 2, Task 3, Task 6  
🧰 Tools Used: Python, pandas, seaborn, matplotlib, scikit-learn, yfinance

---

## ✅ Task Overview

### 🔍 Task 1: Exploring and Visualizing a Simple Dataset
- **Objective:** Load, inspect, and visualize the Iris dataset to understand feature distributions and relationships.
- **Dataset:** Iris Dataset (available via seaborn or CSV)
- **Techniques Used:**
  - Data inspection with `.head()`, `.info()`, `.describe()`
  - Visualizations: scatter plots, histograms, box plots
- **Skills Practiced:** Data exploration, basic plotting, data summary

🔗 [`View Task 1`](./Task1_Exploring_Iris_Dataset/README.md)

---

### 📈 Task 2: Predict Future Stock Prices
- **Objective:** Predict the next day’s stock closing price using historical stock market data.
- **Dataset:** Retrieved using `yfinance` (e.g., Apple, Tesla)
- **Models Used:** Linear Regression / Random Forest
- **Features:** Open, High, Low, Volume → Predict Close
- **Visualizations:** Actual vs Predicted Closing Prices
- **Skills Practiced:** Time series regression, API data fetching, model evaluation

🔗 [`View Task 2`](./Task2_Stock_Price_Prediction/README.md)

---

### ❤️ Task 3: Heart Disease Prediction
- **Objective:** Predict whether a person is at risk of heart disease based on health metrics.
- **Dataset:** UCI Heart Disease Dataset (Kaggle)
- **Models Used:** Logistic Regression, Decision Tree
- **Evaluation Metrics:** Accuracy, ROC Curve, Confusion Matrix
- **Highlights:** Feature importance analysis, medical data interpretation

🔗 [`View Task 3`](./Task3_Heart_Disease_Prediction/README.md)

---

### 🏠 Task 6: House Price Prediction
- **Objective:** Predict house prices using features like size, bedrooms, and location.
- **Dataset:** House Price Prediction Dataset (Kaggle)
- **Models Used:** Linear Regression, Gradient Boosting
- **Preprocessing:** Feature scaling and encoding
- **Evaluation Metrics:** Mean Absolute Error (MAE), Root Mean Square Error (RMSE)
- **Visualizations:** Actual vs Predicted Price Scatter

🔗 [`View Task 6`](./Task6_House_Price_Prediction/README.md)

---

## 📁 Repository Structure

