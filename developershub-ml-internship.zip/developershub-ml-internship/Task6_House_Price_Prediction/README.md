# 🏡 House Price Prediction — Task 6

This project demonstrates how to build regression models to predict house prices based on various features across multiple cities. The notebook walks through data cleaning, preprocessing, model training, and evaluation.

---

## ✨ Project Overview

**Objective:**  
Predict the price of a house using structured data with numeric and categorical variables.

**Dataset:**  
`house_data_multicity.csv` — a dataset containing housing information across multiple cities.

**Workflow:**
- Load and inspect the dataset
- Clean missing or inconsistent data
- Preprocess features (scaling, encoding)
- Train regression models (Linear Regression and Gradient Boosting)
- Evaluate model performance
- Visualize predictions

---

## 🛠️ Technologies and Libraries

- Python 3.x
- pandas — data manipulation
- numpy — numerical operations
- scikit-learn — preprocessing, modeling, evaluation
- matplotlib, seaborn — visualization
- Jupyter Notebook — interactive development

---
