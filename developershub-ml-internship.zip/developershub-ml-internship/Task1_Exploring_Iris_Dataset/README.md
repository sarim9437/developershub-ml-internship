# Task 1: Exploring and Visualizing the Iris Dataset

## 🎯 Objective
To understand and visualize the Iris dataset using pandas, matplotlib, and seaborn. The task focuses on gaining insights into the relationships and distributions of flower features.

## 📊 Dataset
- Name: Iris
- Source: `seaborn.load_dataset("iris")`
- Features: `sepal_length`, `sepal_width`, `petal_length`, `petal_width`
- Target: `species`

## 📌 Tasks Performed
- Loaded and inspected the dataset (shape, types, basic stats)
- Used `.describe()` and `.info()` for summaries
- Created:
  - Pairwise scatter plots
  - Histograms
  - Box plots by species

## 📈 Key Insights
- Petal features are the most distinguishing among species.
- Setosa is clearly separated from the others.
- Histograms and box plots confirm consistency of species-specific characteristics.

## 🛠️ Tools Used
- Python
- Pandas
- Seaborn
- Matplotlib
- Jupyter Notebook
